package mmm.lib;

public class Packet250CustomPayload {
	public Packet250CustomPayload(String string, byte[] pData) {
		// TODO 自動生成されたコンストラクター・スタブ
	}

	public byte data[];
}
