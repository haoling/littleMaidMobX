package mmm.lib;

import java.util.ArrayList;
import java.util.Map;

import cpw.mods.fml.common.ObfuscationReflectionHelper;
import lmm.LMM_EntityLittleMaid;
import lmm.LMM_EntityMode_Test;
import lmm.LMM_GuiIFF;
import lmm.LMM_littleMaidMob;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.entity.ai.EntityAITasks;
import net.minecraft.entity.ai.EntityAITasks.EntityAITaskEntry;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.inventory.Container;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.Achievement;
import net.minecraft.world.biome.BiomeGenBase;

public class ModLoader
{
	public static void addLocalization(String a, String b)
	{
		
	}

	public static void addLocalization(String a, String lng, String b)
	{
		
	}

	public static void addAchievementDesc(Achievement ac_Contract, String string, String string2)
	{
	}

	public static void addRecipe(ItemStack itemStack, Object[] objects)
	{
	}

	public static <T, E> T getPrivateValue(Class <? super E > classToAccess, E instance, int fieldIndex)
	{
		return ObfuscationReflectionHelper.getPrivateValue(classToAccess, instance, fieldIndex);
	}
	public static <T, E> T getPrivateValue(Class <? super E > classToAccess, E instance, String... fieldNames)
	{
		return ObfuscationReflectionHelper.getPrivateValue(classToAccess, instance, fieldNames);
	}

	public static void openGUI(EntityPlayer pPlayer, LMM_GuiIFF lmm_GuiIFF)
	{
	}

	public static void addCommand(LMM_EntityMode_Test lmm_EntityMode_Test) {}

	public static void setPrivateValue(Class<EntityCreeper> class1,
			EntityCreeper pEntity, int i, int j) {
	}

	public static void serverOpenWindow(EntityPlayerMP pEntityPlayer,
			Container lcontainer, int containerID, int entityId, int i, int j) {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	public static void addSpawn(Class<LMM_EntityLittleMaid> class1,
			int cfg_spawnWeight, int cfg_minGroupSize, int cfg_maxGroupSize,
			EnumCreatureType creature) {
	}

	public static void registerPacketChannel(
			LMM_littleMaidMob mod_LMM_littleMaidMob, String string) {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	public static void registerContainerID(
			LMM_littleMaidMob mod_LMM_littleMaidMob, int containerID) {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	public static void addSpawn(Class<LMM_EntityLittleMaid> class1,
			int cfg_spawnWeight, int cfg_minGroupSize, int cfg_maxGroupSize,
			EnumCreatureType creature, BiomeGenBase[] dominateBiomes) {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	public static void clientSendPacket(
			Packet250CustomPayload packet250CustomPayload) {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	public static void serverSendPacket(NetServerHandler pHandler,
			Packet250CustomPayload packet250CustomPayload) {
		// TODO 自動生成されたメソッド・スタブ
		
	}
}
