package mmm.lib;

public class ProxyCommon {

	public void init() {
	}

}
