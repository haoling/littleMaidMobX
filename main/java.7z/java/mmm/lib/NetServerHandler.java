package mmm.lib;

import net.minecraft.entity.player.EntityPlayer;

public class NetServerHandler
{

	public EntityPlayer playerEntity;

}
